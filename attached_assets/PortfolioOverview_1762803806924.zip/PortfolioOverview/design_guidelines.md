# Design Guidelines: Ayush Sharma Political Portfolio

## Design Approach
**Reference-Based Approach** drawing from professional political campaign sites and modern portfolio platforms like Barack Obama's campaign site, Justin Trudeau's official site, and premium portfolio platforms like Webflow showcases. Emphasis on credibility, accessibility, and inspiring leadership presence.

## Core Design Principles
- **Professional Authority**: Clean, structured layouts that communicate competence and trustworthiness
- **Youth & Innovation**: Modern digital-first aesthetic that balances tradition with forward-thinking
- **Accessibility First**: Clear hierarchy, readable typography, generous whitespace for broad audience reach
- **Mission-Driven**: Every section reinforces leadership vision and public service commitment

## Typography System
**Font Selection**: 
- Primary: Inter or similar geometric sans-serif (Google Fonts)
- Headings: Bold weights (700-800) for authority
- Body: Regular/Medium (400-500) for readability

**Type Scale**:
- Hero Headline: text-5xl md:text-6xl lg:text-7xl, font-bold
- Section Headings: text-3xl md:text-4xl lg:text-5xl, font-bold
- Subsection Headings: text-2xl md:text-3xl, font-semibold
- Body Text: text-base md:text-lg, leading-relaxed
- Labels/Metadata: text-sm, uppercase tracking-wide for emphasis

## Layout System
**Spacing Primitives**: Use Tailwind units of 4, 6, 8, 12, 16, 20, 24 for consistency
- Section vertical padding: py-16 md:py-24 lg:py-32
- Component spacing: gap-8 md:gap-12
- Container: max-w-7xl mx-auto px-6 md:px-8

**Grid Strategy**:
- Skills grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-4
- Case studies: grid-cols-1 md:grid-cols-2 gap-8
- Gallery: grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4

## Section Structure

### 1. Navigation
Fixed header with logo/name, smooth scroll navigation links (About, Skills, Experience, Vision, Gallery, Contact), and prominent CTA button. Transparent on scroll with backdrop blur.

### 2. Hero Section
Full viewport height (min-h-screen) with professional portrait/campaign-style image background. Overlay gradient for text legibility. Centered content with:
- Powerful tagline (text-5xl-7xl)
- Professional subtitle with credentials
- Two CTAs (primary: "View My Work", secondary: "Get In Touch") with blurred backgrounds
- Subtle scroll indicator

### 3. About Section
Two-column layout (lg:grid-cols-2) with:
- Left: Professional headshot with subtle border treatment
- Right: Compelling narrative about political journey, education (MCA + Mass Comm), and mission
- Key statistics callout cards (3-4 metrics in grid)

### 4. Skills Showcase
Four-column grid presenting skill categories with icon + title + description cards:
- Political Strategy & Leadership
- Communication & Public Engagement  
- Digital & Social Media Strategy
- Technical & Data Skills
Each card features icon, bold category title, and bullet list of competencies

### 5. Experience & Case Studies
Timeline-style layout alternating sides with:
- Project cards showing campaign work
- Structured format: Title, Goal, Role, Strategy, Results
- Visual elements (icons, metrics visualization)
- Hover effects revealing additional details

### 6. Leadership Philosophy
Centered content section with:
- Inspirational quote treatment (large, serif accent font)
- Multi-paragraph philosophy statement
- Pull quotes highlighted in accent treatment
- Background subtle texture or pattern

### 7. Achievements & Vision
Split layout:
- Left: Achievement timeline with icons and descriptions
- Right: Future vision statement with bold goals
- Decorative connecting line element

### 8. Work Gallery
Masonry-style grid or card grid showcasing:
- Campaign materials, social media highlights, public speaking moments
- Lightbox interaction for detail view
- Category filters (optional: Campaigns, Social Media, Public Events)

### 9. Contact Section
Centered card design with:
- Headline encouraging collaboration
- Contact form (Name, Email, Message fields)
- Social media icon links (LinkedIn, Twitter/X, Instagram)
- Location badge (India)
- Alternative: Email link with professional email address

### 10. Footer
Simple, clean footer with:
- Quick navigation links
- Social media icons
- Copyright and "Built with purpose" tagline
- Newsletter signup for political updates

## Component Library

**Buttons**:
- Primary: Solid with rounded corners (rounded-lg), px-8 py-4, bold text
- Secondary: Outline style with same padding
- All buttons have backdrop-blur when on images

**Cards**:
- Rounded corners (rounded-xl)
- Subtle shadow (shadow-lg hover:shadow-xl transition)
- Padding: p-6 md:p-8
- Border treatment on hover

**Icons**:
Use Heroicons for UI elements, political/social icons from Font Awesome
- Consistent sizing: w-6 h-6 for inline, w-12 h-12 for feature icons
- Single color treatment matching theme

**Forms**:
- Generous input padding (px-4 py-3)
- Clear labels with proper spacing
- Focus states with border accent
- Rounded inputs (rounded-lg)

## Images

**Large Hero Image**: 
Professional portrait or campaign-style photograph of Ayush Sharma in formal/smart-casual attire, looking confident and approachable. Shot should convey leadership and youthfulness. Image spans full viewport with gradient overlay.

**About Section Image**:
Professional headshot, square or vertical orientation, high quality with neutral/office background.

**Gallery Images**:
Collection of 12-16 images showing:
- Campaign event photos
- Social media content screenshots
- Public speaking moments
- Community engagement activities
- Digital strategy work samples
- Data visualization examples from campaigns

All images should maintain consistent quality and professional aesthetic. Use image optimization for web performance.

## Animations
Minimal and purposeful:
- Smooth scroll behavior
- Fade-in on scroll for sections (subtle, 200-300ms)
- Button hover scale (scale-105)
- Card hover lift effects
- NO complex scroll-triggered animations or parallax

## Accessibility
- ARIA labels on all interactive elements
- Keyboard navigation support throughout
- Sufficient color contrast ratios (WCAG AA minimum)
- Focus indicators clearly visible
- Semantic HTML structure
- Alt text for all images describing political context