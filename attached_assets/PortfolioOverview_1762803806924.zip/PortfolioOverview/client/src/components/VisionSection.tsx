import { Card } from "@/components/ui/card";
import { Quote, Lightbulb, Heart, Users, Globe } from "lucide-react";

const achievements = [
  {
    icon: Users,
    year: "Dec 2024",
    title: "Janmat Political Consulting",
    description:
      "Currently managing social media accounts for MLAs and MPs, creating engaging content and driving digital campaigns",
  },
  {
    icon: Lightbulb,
    year: "Dec 2023",
    title: "2023 State Elections",
    description:
      "Successfully managed MLA candidate's social media during elections and led volunteer teams for national party",
  },
  {
    icon: Heart,
    year: "Training",
    title: "CM's Election Training",
    description:
      "Attended 3-day election training program by former Chief Minister of Madhya Pradesh",
  },
];

const visionPoints = [
  {
    icon: Globe,
    title: "Help Political Leaders Win Digitally",
    description:
      "Provide comprehensive social media management services that help political leaders build strong online presence and connect authentically with voters",
  },
  {
    icon: Users,
    title: "Scale Social Media Services",
    description:
      "Expand services to support more MLAs, MPs, and political candidates across India with professional digital campaign management",
  },
  {
    icon: Lightbulb,
    title: "Innovate Political Communication",
    description:
      "Combine ground-level political understanding with digital expertise to create campaigns that resonate with citizens and deliver measurable results",
  },
];

export default function VisionSection() {
  return (
    <section id="vision" className="py-16 md:py-24 lg:py-32 bg-card">
      <div className="max-w-7xl mx-auto px-6 md:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4"
            data-testid="text-vision-heading"
          >
            Leadership Philosophy & Vision
          </h2>
        </div>

        <div className="mb-16">
          <Card className="p-8 md:p-12 bg-primary/5 border-primary/20">
            <Quote className="w-12 h-12 text-primary mb-6" />
            <blockquote className="font-serif text-xl md:text-2xl lg:text-3xl leading-relaxed mb-6">
              "In today's digital age, political success requires more than just ground presence—it demands a strategic social media voice that resonates with citizens and builds lasting connections."
            </blockquote>
            <div className="prose prose-lg max-w-none text-muted-foreground">
              <p className="leading-relaxed">
                My approach to social media management is built on <strong>authenticity</strong>,{" "}
                <strong>strategic thinking</strong>, and{" "}
                <strong>measurable results</strong>. I believe every political leader deserves a strong digital presence that reflects their values and connects genuinely with their constituents.
              </p>
              <p className="leading-relaxed">
                By combining ground-level political understanding with digital expertise, I help leaders navigate the complex world of social media, build their online reputation, and engage meaningfully with voters. Every post, every campaign, and every strategy is designed to amplify your message and strengthen your political brand.
              </p>
            </div>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 md:gap-16">
          <div>
            <h3 className="text-2xl md:text-3xl font-bold mb-8">
              Achievements
            </h3>
            <div className="space-y-6">
              {achievements.map((achievement, index) => (
                <Card
                  key={index}
                  className="p-6 hover-elevate"
                  data-testid={`card-achievement-${index}`}
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-primary/10 rounded-lg flex-shrink-0">
                      <achievement.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-bold text-primary mb-1">
                        {achievement.year}
                      </div>
                      <h4 className="font-bold text-lg mb-2">
                        {achievement.title}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {achievement.description}
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-2xl md:text-3xl font-bold mb-8">
              Future Vision
            </h3>
            <div className="space-y-6">
              {visionPoints.map((point, index) => (
                <Card
                  key={index}
                  className="p-6 hover-elevate"
                  data-testid={`card-vision-${index}`}
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-primary/10 rounded-lg flex-shrink-0">
                      <point.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-lg mb-2">{point.title}</h4>
                      <p className="text-sm text-muted-foreground">
                        {point.description}
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
