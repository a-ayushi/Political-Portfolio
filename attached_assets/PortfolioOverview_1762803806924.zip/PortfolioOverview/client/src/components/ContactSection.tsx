import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail, MapPin, Phone } from "lucide-react";
import { SiLinkedin, SiX, SiInstagram } from "react-icons/si";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    alert("Thank you for reaching out! I'll get back to you soon.");
    setFormData({ name: "", email: "", message: "" });
  };

  const socialLinks = [
    {
      icon: SiLinkedin,
      label: "LinkedIn",
      url: "#",
      color: "text-[#0A66C2]",
    },
    {
      icon: SiX,
      label: "Twitter/X",
      url: "#",
      color: "text-[#000000] dark:text-[#FFFFFF]",
    },
    {
      icon: SiInstagram,
      label: "Instagram",
      url: "#",
      color: "text-[#E4405F]",
    },
  ];

  return (
    <section id="contact" className="py-16 md:py-24 lg:py-32 bg-card">
      <div className="max-w-7xl mx-auto px-6 md:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4"
            data-testid="text-contact-heading"
          >
            Let's Connect
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Looking to boost your political presence on social media? Let's discuss how I can help you connect with your constituents and grow your digital influence.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <Card className="p-8 md:p-10">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label
                    htmlFor="name"
                    className="block text-sm font-semibold mb-2"
                  >
                    Your Name
                  </label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Enter your name"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    required
                    data-testid="input-name"
                  />
                </div>

                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-semibold mb-2"
                  >
                    Email Address
                  </label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    required
                    data-testid="input-email"
                  />
                </div>

                <div>
                  <label
                    htmlFor="message"
                    className="block text-sm font-semibold mb-2"
                  >
                    Message
                  </label>
                  <Textarea
                    id="message"
                    placeholder="Tell me about your project or how we can collaborate..."
                    value={formData.message}
                    onChange={(e) =>
                      setFormData({ ...formData, message: e.target.value })
                    }
                    rows={6}
                    required
                    data-testid="input-message"
                  />
                </div>

                <Button type="submit" className="w-full" data-testid="button-submit">
                  Send Message
                </Button>
              </form>
            </Card>
          </div>

          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold mb-6">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <Phone className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Phone</div>
                    <a
                      href="tel:+919893064257"
                      className="font-semibold hover:text-primary transition-colors"
                      data-testid="link-phone"
                    >
                      +91-9893064257
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <Mail className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Email</div>
                    <a
                      href="mailto:ayushsharma.chh@gmail.com"
                      className="font-semibold hover:text-primary transition-colors"
                      data-testid="link-email"
                    >
                      ayushsharma.chh@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <MapPin className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">
                      Location
                    </div>
                    <div className="font-semibold" data-testid="text-location">Indore, Madhya Pradesh, India</div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold mb-6">Connect on Social Media</h3>
              <div className="flex gap-4">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-4 bg-card border rounded-lg hover-elevate active-elevate-2 transition-all"
                    data-testid={`link-social-${social.label.toLowerCase().replace('/', '-')}`}
                  >
                    <social.icon className={`w-6 h-6 ${social.color}`} />
                  </a>
                ))}
              </div>
              <p className="mt-6 text-sm text-muted-foreground">
                Follow me for insights on political strategy, digital
                communication, and leadership perspectives.
              </p>
            </div>

            <Card className="p-6 bg-primary/5 border-primary/20">
              <h4 className="font-bold mb-3">Services Offered</h4>
              <ul className="text-sm text-muted-foreground leading-relaxed space-y-2">
                <li>• Complete Social Media Account Management</li>
                <li>• Content Creation (Posts, Reels, Videos)</li>
                <li>• Digital Campaign Strategy & Execution</li>
                <li>• Online Reputation Management</li>
                <li>• Analytics & Performance Reporting</li>
                <li>• Ground Team Coordination</li>
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
