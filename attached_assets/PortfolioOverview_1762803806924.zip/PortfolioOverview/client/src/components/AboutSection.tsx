import { Card } from "@/components/ui/card";
import { Users, TrendingUp, Award, Target } from "lucide-react";
import profileImage from "@assets/ayush_profile.jpg";

const stats = [
  { icon: Users, label: "Political Leaders Served", value: "MLAs & MPs" },
  { icon: TrendingUp, label: "Social Media Growth", value: "2x Engagement" },
  { icon: Award, label: "Campaigns Managed", value: "Multiple" },
  { icon: Target, label: "Platform Expertise", value: "All Major" },
];

export default function AboutSection() {
  return (
    <section id="about" className="py-16 md:py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6 md:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4"
            data-testid="text-about-heading"
          >
            About Me
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A young political thinker combining technology, communication, and
            political understanding
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 md:gap-16 items-center">
          <div className="flex justify-center">
            <div className="relative">
              <div className="w-72 h-96 md:w-80 md:h-[28rem] rounded-xl overflow-hidden border-4 border-card shadow-xl">
                <img
                  src={profileImage}
                  alt="Ayush Sharma"
                  className="w-full h-full object-cover"
                  data-testid="img-profile"
                />
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="prose prose-lg max-w-none">
              <p className="text-foreground leading-relaxed" data-testid="text-about-bio">
                I am <strong>Ayush Sharma</strong>, a professional social media manager specializing in political digital campaigns. Based in <strong>Indore, Madhya Pradesh</strong>, I help political leaders—MLAs, MPs, and aspiring candidates—build a powerful online presence and connect meaningfully with their constituents.
              </p>
              <p className="text-foreground leading-relaxed">
                Currently working with <strong>Janmat Political Consulting</strong>, I manage social media accounts for multiple political leaders across all major platforms. From creating engaging posts and viral reels to planning comprehensive digital campaigns, I ensure your message reaches the right audience at the right time.
              </p>
              <p className="text-foreground leading-relaxed">
                My expertise includes <strong>team management, booth-level coordination, social media analytics, ground surveys,</strong> and <strong>media monitoring</strong>. I've successfully managed campaigns during the 2023 state elections and worked with national-level political parties, combining grassroots understanding with digital strategy to deliver measurable results.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4">
              {stats.map((stat, index) => (
                <Card
                  key={index}
                  className="p-4 text-center hover-elevate"
                  data-testid={`card-stat-${index}`}
                >
                  <stat.icon className="w-6 h-6 mx-auto mb-2 text-primary" />
                  <div className="text-xl md:text-2xl font-bold">
                    {stat.value}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {stat.label}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
