import ContactSection from "../ContactSection";

export default function ContactSectionExample() {
  return <ContactSection />;
}
