import VisionSection from "../VisionSection";

export default function VisionSectionExample() {
  return <VisionSection />;
}
