import GallerySection from "../GallerySection";

export default function GallerySectionExample() {
  return <GallerySection />;
}
