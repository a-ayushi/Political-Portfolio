import { Button } from "@/components/ui/button";
import { ArrowDown } from "lucide-react";
import heroImage from "@assets/generated_images/Campaign_event_speaking_e22023f4.png";

interface HeroSectionProps {
  onCtaClick?: (action: string) => void;
}

export default function HeroSection({ onCtaClick }: HeroSectionProps) {
  const handleCtaClick = (action: string) => {
    onCtaClick?.(action);
    const target = action === "view-work" ? "#experience" : "#contact";
    document.querySelector(target)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${heroImage})`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-8 py-32 md:py-40 text-center">
        <div className="space-y-6 md:space-y-8">
          <h1
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight"
            data-testid="text-hero-headline"
          >
            Amplify Your Political Voice
            <br />
            With Strategic Social Media
          </h1>

          <p
            className="text-lg md:text-xl lg:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed"
            data-testid="text-hero-subtitle"
          >
            Social Media Manager for Political Leaders | Digital Campaign Expert | Helping MLAs & MPs Connect with Citizens
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Button
              size="lg"
              onClick={() => handleCtaClick("view-work")}
              className="px-8 backdrop-blur-sm"
              data-testid="button-view-work"
            >
              View My Work
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => handleCtaClick("contact")}
              className="px-8 backdrop-blur-md bg-background/20"
              data-testid="button-get-in-touch"
            >
              Get In Touch
            </Button>
          </div>

          <div className="pt-12 animate-bounce">
            <ArrowDown className="w-6 h-6 mx-auto text-muted-foreground" />
          </div>
        </div>
      </div>
    </section>
  );
}
