import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";
import campaignImage from "@assets/generated_images/Campaign_event_speaking_e22023f4.png";
import workspaceImage from "@assets/generated_images/Digital_strategy_workspace_2d3bebc8.png";
import communityImage from "@assets/generated_images/Community_engagement_meeting_c02391bc.png";
import socialMediaImage from "@assets/generated_images/Social_media_content_a5433389.png";
import speakingImage from "@assets/generated_images/Public_speaking_engagement_88a7d6de.png";

const galleryItems = [
  {
    image: campaignImage,
    title: "Campaign Event Leadership",
    category: "Public Events",
    description: "Addressing community members at political rally",
  },
  {
    image: workspaceImage,
    title: "Digital Strategy Planning",
    category: "Social Media",
    description: "Data-driven campaign analytics and strategy",
  },
  {
    image: communityImage,
    title: "Grassroots Engagement",
    category: "Community",
    description: "Connecting with citizens and community leaders",
  },
  {
    image: socialMediaImage,
    title: "Social Media Content",
    category: "Social Media",
    description: "Creating engaging political content",
  },
  {
    image: speakingImage,
    title: "Public Speaking",
    category: "Public Events",
    description: "Town hall and community forums",
  },
  {
    image: campaignImage,
    title: "Campaign Strategy",
    category: "Campaigns",
    description: "Strategic planning and execution",
  },
];

export default function GallerySection() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  return (
    <section id="gallery" className="py-16 md:py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6 md:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4"
            data-testid="text-gallery-heading"
          >
            Work Gallery
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A visual journey through campaigns, community engagement, and
            digital strategy work
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {galleryItems.map((item, index) => (
            <Card
              key={index}
              className="overflow-hidden cursor-pointer hover-elevate group"
              onClick={() => setSelectedImage(index)}
              data-testid={`card-gallery-${index}`}
            >
              <div className="aspect-square relative overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <Badge variant="secondary" className="mb-2 text-xs">
                      {item.category}
                    </Badge>
                    <h4 className="font-bold text-sm">{item.title}</h4>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {selectedImage !== null && (
          <div
            className="fixed inset-0 bg-background/95 backdrop-blur-md z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedImage(null)}
          >
            <button
              className="absolute top-4 right-4 p-2 rounded-full bg-card hover-elevate"
              onClick={() => setSelectedImage(null)}
              data-testid="button-close-lightbox"
            >
              <X className="w-6 h-6" />
            </button>
            <div className="max-w-5xl w-full">
              <img
                src={galleryItems[selectedImage].image}
                alt={galleryItems[selectedImage].title}
                className="w-full h-auto rounded-lg"
              />
              <div className="mt-6 text-center">
                <Badge variant="secondary" className="mb-3">
                  {galleryItems[selectedImage].category}
                </Badge>
                <h3 className="text-2xl font-bold mb-2">
                  {galleryItems[selectedImage].title}
                </h3>
                <p className="text-muted-foreground">
                  {galleryItems[selectedImage].description}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
