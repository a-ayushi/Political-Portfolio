import { Card } from "@/components/ui/card";
import { Target, MessageCircle, Share2, BarChart3 } from "lucide-react";

const skillCategories = [
  {
    icon: Share2,
    title: "Social Media Management",
    skills: [
      "Multi-Platform Account Management",
      "Content Creation (Posts, Reels, Videos)",
      "Digital Campaign Planning",
      "Online Reputation Management",
      "Social Media Analytics & Reporting",
    ],
  },
  {
    icon: Target,
    title: "Campaign Strategy & Leadership",
    skills: [
      "Team Management & Coordination",
      "Booth Level Management",
      "Election Campaign Strategy",
      "Volunteer Leadership",
      "Ground-to-Digital Integration",
    ],
  },
  {
    icon: BarChart3,
    title: "Research & Monitoring",
    skills: [
      "Ground Survey & Data Collection",
      "Media Monitoring & Analysis",
      "Rebel Tracking & Opposition Research",
      "Public Sentiment Analysis",
      "Performance Metrics & Insights",
    ],
  },
  {
    icon: MessageCircle,
    title: "Political Communication",
    skills: [
      "Grassroots Engagement",
      "Public Messaging & Positioning",
      "Crisis Communication",
      "Real-time Event Coverage",
      "Constituent Relations",
    ],
  },
];

export default function SkillsSection() {
  return (
    <section id="skills" className="py-16 md:py-24 lg:py-32 bg-card">
      <div className="max-w-7xl mx-auto px-6 md:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4"
            data-testid="text-skills-heading"
          >
            Skills & Expertise
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A comprehensive skill set spanning political strategy, digital
            communication, and data-driven leadership
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {skillCategories.map((category, index) => (
            <Card
              key={index}
              className="p-6 md:p-8 hover-elevate"
              data-testid={`card-skill-category-${index}`}
            >
              <category.icon className="w-10 h-10 md:w-12 md:h-12 mb-4 text-primary" />
              <h3 className="text-xl font-bold mb-4">{category.title}</h3>
              <ul className="space-y-2">
                {category.skills.map((skill, skillIndex) => (
                  <li
                    key={skillIndex}
                    className="text-sm text-muted-foreground flex items-start"
                  >
                    <span className="mr-2 text-primary">•</span>
                    <span>{skill}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
