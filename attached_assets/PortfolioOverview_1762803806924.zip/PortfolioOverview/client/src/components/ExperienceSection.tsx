import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Target, Users, TrendingUp, Award } from "lucide-react";

const caseStudies = [
  {
    icon: Users,
    title: "Social Media Management - Janmat Political Consulting",
    goal: "Manage social media presence for MLAs and MPs to increase public engagement",
    role: "Social Media Manager - Handle accounts across major platforms, create content, plan campaigns",
    strategy:
      "Daily content creation (posts, reels, videos), digital campaign planning, real-time event coverage, metrics analysis, ground team coordination",
    results: [
      "Managing multiple MLA/MP accounts",
      "Consistent engagement growth",
      "Professional content delivery",
      "Strategic campaign execution",
    ],
    tags: ["Current Role", "Social Media", "Campaign Management"],
  },
  {
    icon: Target,
    title: "MLA Social Media Campaign - 2023 State Elections",
    goal: "Enhance MLA candidate's social media presence during state elections",
    role: "Social Media Manager - Managed candidate's digital presence and public engagement strategy",
    strategy:
      "Multi-platform content strategy, real-time updates, public messaging, voter engagement campaigns",
    results: [
      "Increased online visibility",
      "Enhanced public engagement",
      "Strategic message amplification",
      "Successful election support",
    ],
    tags: ["Elections 2023", "MLA Campaign", "Digital Strategy"],
  },
  {
    icon: TrendingUp,
    title: "National Party Digital Outreach",
    goal: "Support national-level political party during elections at grassroots level",
    role: "Team Leader & Social Media Strategist - Led volunteer teams and managed digital outreach",
    strategy:
      "Grassroots coordination with Sarpanch, Janpad & Jila Panchayat members, volunteer team leadership, social media strategy for voter awareness",
    results: [
      "Successful ground-level coordination",
      "Volunteer team leadership",
      "Increased voter awareness",
      "Multi-level political engagement",
    ],
    tags: ["National Party", "Team Leadership", "Grassroots"],
  },
];

export default function ExperienceSection() {
  return (
    <section id="experience" className="py-16 md:py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6 md:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4"
            data-testid="text-experience-heading"
          >
            Experience & Case Studies
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Strategic campaigns and initiatives demonstrating measurable impact
            and community engagement
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {caseStudies.map((study, index) => (
            <Card
              key={index}
              className="p-6 md:p-8 hover-elevate"
              data-testid={`card-case-study-${index}`}
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <study.icon className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold mb-2">{study.title}</h3>
                  <div className="flex flex-wrap gap-2">
                    {study.tags.map((tag, tagIndex) => (
                      <Badge
                        key={tagIndex}
                        variant="secondary"
                        className="text-xs"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <div className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-1">
                    Goal
                  </div>
                  <p className="text-sm">{study.goal}</p>
                </div>

                <div>
                  <div className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-1">
                    My Role
                  </div>
                  <p className="text-sm">{study.role}</p>
                </div>

                <div>
                  <div className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-1">
                    Strategy
                  </div>
                  <p className="text-sm">{study.strategy}</p>
                </div>

                <div>
                  <div className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-1">
                    Results
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {study.results.map((result, resultIndex) => (
                      <div
                        key={resultIndex}
                        className="flex items-center gap-2 text-sm"
                      >
                        <Award className="w-4 h-4 text-primary flex-shrink-0" />
                        <span>{result}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
